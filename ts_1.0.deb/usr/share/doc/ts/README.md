# ts - Timestamp Files
## Terminal Usage:
##        ts -c -s filename (copy file - short timestamp)
##        ts -c -f filename (copy file - full timestamp)
##        ts -m -s filename (move file - short timestamp)
##        ts -m -f filename (move file - full timestamp)


